import 'package:flutter/material.dart';

class PushPullScrollPosition extends ScrollPositionWithSingleContext {
  PushPullScrollPosition({
    ScrollPhysics physics,
    ScrollContext context,
    ScrollPosition oldPosition,
    double initialPixels,
  }) : super(
            physics: physics,
            context: context,
            oldPosition: oldPosition,
            initialPixels: initialPixels);

  double myMinScrollExtent = double.negativeInfinity;

  @override
  double get minScrollExtent => myMinScrollExtent;
}