import 'package:flutter/material.dart';
import './PushPullScrollPosition.dart';

class PushPullScrollController extends ScrollController {
  PushPullScrollController({
    double initialScrollOffset = 0.0,
    keepScrollOffset = true,
  }) : super(
            initialScrollOffset: initialScrollOffset,
            keepScrollOffset: keepScrollOffset);
  @override
  ScrollPosition createScrollPosition(
    ScrollPhysics physics,
    ScrollContext context,
    ScrollPosition oldPosition,
  ) {
    return new PushPullScrollPosition(
      physics: physics,
      context: context,
      oldPosition: oldPosition,
      initialPixels: initialScrollOffset,
    );
  }
}
