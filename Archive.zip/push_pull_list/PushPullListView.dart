import 'package:flutter/material.dart';
import './PushPullScrollPosition.dart';
import './PushPullScrollController.dart';
import 'dart:async';
import '../rect_getter.dart';

typedef OnRefreshFunc = Future<int> Function(bool isTop);

class PushPullListView extends StatefulWidget {
  final int startIndex;
  final int itemCount;
  final IndexedWidgetBuilder itemBuilder;
  final OnRefreshFunc onRefresh;

  const PushPullListView(
      {Key key,
      this.itemBuilder,
      this.onRefresh,
      this.startIndex = 0,
      this.itemCount = 0})
      : assert(0 <= startIndex && startIndex <= itemCount),
        super(key: key);

  _S createState() => new _S(this.startIndex);
}

class _S extends State<PushPullListView> {
  PushPullScrollController _negativeController =
      new PushPullScrollController(initialScrollOffset: -10000.0);
  PushPullScrollController _controller = new PushPullScrollController();
  bool _isLoadingTop;
  int _startIndex;

  _S(this._startIndex);

  @override
  void initState() {
    super.initState();
    _isLoadingTop = false;
  }

  @override
  Widget build(BuildContext context) {
    print('build ....');
    var globalListKey = RectGetter.createGlobalKey();
    var _kIndicatorKey = RectGetter.createGlobalKey();

    bool isTail() {
      var rect = RectGetter.getRectFromKey(globalListKey);
      var indRect = RectGetter.getRectFromKey(_kIndicatorKey);
      return (indRect != null && rect != null && indRect.bottom > rect.top);
    }

    Future<int> _onTop() async {
      int count;
      print('_onTop start ...');
      try {
        count = await widget.onRefresh(true);
      } catch (e) {
        print('err:${e}');
      }
      print('_onTop end ...');
      return count;
    }

    Future<int> _onDown() async {
      int count;
      print('_onDown start ....');
      try {
        count = await widget.onRefresh(false);
      } catch (e) {
        print('err:${e}');
      }
      print('_onDown end ....');
      return count;
    }

    var downlist = NotificationListener<ScrollUpdateNotification>(
        onNotification: (notification) {
          _negativeController.jumpTo(
            -_negativeController.position.extentInside - _controller.offset,
          );

          if (_isLoadingTop) {
            return true;
          }

          if (isTail()) {
            PushPullScrollPosition p = _controller.position;
            if (p.myMinScrollExtent == double.negativeInfinity) {
              p.myMinScrollExtent = -30.0;
              _startIndex = 0;
              setState(() {
                _controller.jumpTo(-100.0);
                _controller.animateTo(-30.0,
                    duration: new Duration(milliseconds: 800),
                    curve: Curves.easeOut);
              });
              return true;
            }

            _isLoadingTop = true;
            _onTop().then((cnt) {
              p.myMinScrollExtent = double.negativeInfinity;
              if (cnt > 0) {
                _startIndex = cnt;
                _isLoadingTop = false;
                return;
              }
              if (cnt == 0) {
                _controller
                    .animateTo(0.0,
                        duration: new Duration(milliseconds: 500),
                        curve: Curves.easeOut)
                    .then((v) {
                  _isLoadingTop = false;
                });
              }
            });
          }

          if (_controller.offset == _controller.position.maxScrollExtent) {
            _isLoadingTop = true;
            PushPullScrollPosition p = _controller.position;
            p.myMinScrollExtent = 0.0;

            _onDown().then((cnt) {
              p.myMinScrollExtent = double.negativeInfinity;
              _isLoadingTop = false;
            });
          }
          return true;
        },
        child: ListView.builder(
          physics: new AlwaysScrollableScrollPhysics(),
          controller: _controller,
          itemCount: widget.itemCount - _startIndex,
          itemBuilder: (BuildContext context, int index) {
            int downIndex = index + _startIndex;
            return widget.itemBuilder(context, downIndex);
          },
        ));

    var root = Stack(
      children: <Widget>[
        Container(
          key: globalListKey,
        ),
        new CustomScrollView(
          physics: new AlwaysScrollableScrollPhysics(),
          controller: _negativeController,
          reverse: true,
          slivers: <Widget>[
            new SliverList(
              delegate:
                  SliverChildBuilderDelegate((BuildContext context, int index) {
                int upIndex = _startIndex - 1 - index;
                if (index == _startIndex) {
                  return RectGetter(
                      key: _kIndicatorKey, child: buildIndicatorBlock());
                }
                return widget.itemBuilder(context, upIndex);
              }, childCount: _startIndex + 1),
            ),
          ],
        ),
        downlist,
      ],
    );
    return root;
  }

  Widget buildIndicatorBlock() {
    var indicator = Container(
      height: 30.0,
      padding: const EdgeInsets.all(0.0),
      child: Center(
        child: SizedBox(
          width: 20.0,
          height: 20.0,
          child: CircularProgressIndicator(strokeWidth: 2.0),
        ),
      ),
    );
    return Container(
        color: Colors.transparent,
        height: 1000.0,
        child: Column(children: <Widget>[
          indicator,
          Expanded(
            flex: 1,
            child: Container(),
          ),
          indicator
        ]));
  }
}
