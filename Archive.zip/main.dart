import 'package:flutter/material.dart';
import './IndexedListViewTest.dart';


void main() {
  runApp(new MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: new ThemeData(primaryColor: AppColor.primaryColor),
      home:
          IndexedListViewTest(),
      ));
}


