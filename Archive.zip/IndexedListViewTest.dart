import 'dart:async';
import 'package:flutter/material.dart';
import './push_pull_list/PushPullListView.dart';

class IndexedListViewTest extends StatefulWidget {
  @override
  _S createState() => _S();
}

class _S extends State<IndexedListViewTest> {
  int uidx = 0;
  int didx = 0;
  List<String> data = List();
  @override
  void initState() {
    super.initState();
    data.addAll(List.generate(20, (i) => 'data:${i}'));
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text('PushPullListView Test'),
      ),
      body: new PushPullListView(
        onRefresh: (bool isTop) async {
          if (isTop) {
            int count = 6;
            await Future.delayed(Duration(milliseconds: 2000), () {
              setState(() {
                if (uidx < 20) {
                  List.generate(count, (i) => '新刷新的up x数据 ${uidx + i}')
                      .forEach((item) {
                    data.insert(0, item);
                  });
                  uidx += count;
                } else {
                  count = 0;
                }
              });
            });
            return count;
          } else {
            int count = 6;
            await Future.delayed(Duration(milliseconds: 2000), () {
              setState(() {
                data.addAll(
                    List.generate(count, (i) => '新刷新的down x数据 ${didx + i}'));
                didx += count;
              });
            });
            return count;
          }
        },
        itemBuilder: (context, index) {
          return Container(
            height: 50.0,
            color: Colors.green,
            child: new Center(child: Text(data[index])),
          );
        },
        itemCount: data.length,
        startIndex: 0,
      ),
    );
  }
}
